from django.db import models


# Create your models here.

class skills(models.Model):
    sno = models.AutoField(primary_key=True)
    skill_name = models.CharField(max_length=50, verbose_name="skill Name")
    percent = models.CharField(max_length=4, verbose_name="skill percent")

    def __str__(self):
        return self.skill_name + "-" + self.percent

class contact(models.Model):
    name=models.CharField(max_length=200)
    email=models.EmailField()
    message=models.TextField()
    def __str__(self):
        return self.name
