from django.shortcuts import render
from .models import skills
from .models import contact
from django.http import HttpResponse


def index(request):
    skill = skills.objects.all()
    context = {"skills":skill}

    if request.method=="POST":
        cont =contact()
        name=request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')
        cont.name=name
        cont.email = email
        cont.message = message
        cont.save()
        return HttpResponse("<h1>Thank You For Contact Us</h1>")
    return render(request,'index.html',context)


