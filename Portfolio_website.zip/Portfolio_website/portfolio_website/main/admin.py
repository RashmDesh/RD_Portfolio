from django.contrib import admin
from .models import skills
from .models import contact
# Register your models here.
admin.site.register(skills)
admin.site.register(contact)
